import math
import time
import sys
import argparse
from datetime import datetime
import os

from bluepy import sensortag
import bluepy

def enableSensors(arg, tag):

	# Enabling selected sensors

	if arg.temperature or arg.all:
		tag.IRtemperature.enable()
		print (str(datetime.now())+'			'+'IRtemperature Sensor Enabled')
	if arg.humidity or arg.all:
		tag.humidity.enable()
		print (str(datetime.now())+'			'+'Humidity Sensor Enabled')
	if arg.barometer or arg.all:
		tag.barometer.enable()
		print (str(datetime.now())+'			'+'Barometer Sensor Enabled')
	if arg.accelerometer or arg.all:
		tag.accelerometer.enable()
		print (str(datetime.now())+'			'+'Accelerometer Sensor Enabled')
	if arg.magnetometer or arg.all:
		tag.magnetometer.enable()
		print (str(datetime.now())+'			'+'Magnetometer Sensor Enabled')
	if arg.gyroscope or arg.all:
		tag.gyroscope.enable()
		print (str(datetime.now())+'			'+'Gyroscope Sensor Enabled')
	if arg.keypress or arg.all:
		tag.keypress.enable()
		tag.setDelegate(sensortag.KeypressDelegate())
		print (str(datetime.now())+'			'+'Keypress Sensor Enabled')
	if arg.light and tag.lightmeter is None:
		print (str(datetime.now())+'			'+'Warning: no light sensor on this device')
	if (arg.light or arg.all) and tag.lightmeter is not None:
		tag.lightmeter.enable()
		print (str(datetime.now())+'			'+'Light Sensor Enabled')



def main():


	#add parse arguement
	parser = argparse.ArgumentParser()
	parser.add_argument('host', action='store',help='MAC of BT device')
	parser.add_argument('-f', '--filepath', action='store',help='path/to/output_csv_file', default='./')
	#parser.add_argument('-n', action='store', dest='count', default=0, type=int, help="Number of times to loop data")
	parser.add_argument('-t',action='store',type=float, default=1.0, help='time between polling')
	parser.add_argument('-T','--temperature', action="store_true",default=False)
	parser.add_argument('-A','--accelerometer', action='store_true', default=False)
	parser.add_argument('-H','--humidity', action='store_true', default=False)
	parser.add_argument('-M','--magnetometer', action='store_true', default=False)
	parser.add_argument('-B','--barometer', action='store_true', default=False)
	parser.add_argument('-G','--gyroscope', action='store_true', default=False)
	parser.add_argument('-K','--keypress', action='store_true', default=False)
	parser.add_argument('-L','--light', action='store_true', default=False)
	parser.add_argument('--all', action='store_true', default=False)

	#parse arguments
	arg = parser.parse_args(sys.argv[1:])

	#connect to sensor tag
	print(str(datetime.now())+'			'+'Connecting to ' + arg.host)
	tag = sensortag.SensorTag(arg.host)

	print (str(datetime.now())+'			'+'Connection Successful')


	enableSensors(arg, tag);

	sys.stdout.flush()




	#wait for sensor initialization
	time.sleep(1.0)
	n=datetime.now()

	print(str(datetime.now())+'			'+'Start Measuring...')
	sys.stdout.flush()

	#store pid
	pid_filename=arg.filepath+str(n.year)+'-'+str(n.month)+'-'+str(n.day)+'_raw_data.pid'
	pid_file=open(pid_filename, 'w')
	pid_file.write(str(os.getpid()))
	pid_file.close()



	#create new csv file
	filename=arg.filepath+str(n.year)+'-'+str(n.month)+'-'+str(n.day)+'_raw_data.csv'
	file=open(filename, 'a')

	'''
	#write csv headers
	header_buffer=''
	header_buffer+=('Time,')
	if arg.temperature or arg.all:
		header_buffer+=('Ambient Temperature (degC),')
		header_buffer+=('Object Temperature (degC),')
	if arg.humidity or arg.all:
		header_buffer+=('Humidity (RH),')
	if arg.barometer or arg.all:
		header_buffer+=('Barometer (millibars),')
	if arg.accelerometer or arg.all:
		header_buffer+=('Accelerometer-x (g),')
		header_buffer+=('Accelerometer-y (g),')
		header_buffer+=('Accelerometer-z (g),')
	if arg.magnetometer or arg.all:
		header_buffer+=('Magnetometer-x (uT),')
		header_buffer+=('Magnetometer-y (uT),')
		header_buffer+=('Magnetometer-z (uT),')
	if arg.gyroscope or arg.all:
		header_buffer+=('Gyroscope-x (deg/sec),')
		header_buffer+=('Gyroscope-y (deg/sec),')
		header_buffer+=('Gyroscope-z (deg/sec),')
	if (arg.light or arg.all) and tag.lightmeter is not None:
		header_buffer+=('Light (lux),')

	file.write(header_buffer[:-1])
	file.write('\n')
	'''


	while True:

		line_buffer=''

		try:
			#file.write(str(datetime.now())+',')
			line_buffer+=(str(datetime.now())+',')
			if arg.temperature or arg.all:
				#file.write(str(tag.IRtemperature.read()[0])+',')
				#file.write(str(tag.IRtemperature.read()[1])+',')
				line_buffer+=(str(tag.IRtemperature.read()[0])+',')
				line_buffer+=(str(tag.IRtemperature.read()[1])+',')

			if arg.humidity or arg.all:
				#file.write(str(tag.humidity.read()[1])+',')
				line_buffer+=(str(tag.humidity.read()[1])+',')
			if arg.barometer or arg.all:
				#file.write(str(tag.barometer.read()[1])+',')
				line_buffer+=(str(tag.barometer.read()[1])+',')
			if arg.accelerometer or arg.all:
				#file.write(str(tag.accelerometer.read()[0])+',')
				#file.write(str(tag.accelerometer.read()[1])+',')
				#file.write(str(tag.accelerometer.read()[2])+',')
				line_buffer+=(str(tag.accelerometer.read()[0])+',')
				line_buffer+=(str(tag.accelerometer.read()[1])+',')
				line_buffer+=(str(tag.accelerometer.read()[2])+',')
			if arg.magnetometer or arg.all:
				line_buffer+=(str(tag.magnetometer.read()[0])+',')
				line_buffer+=(str(tag.magnetometer.read()[1])+',')
				line_buffer+=(str(tag.magnetometer.read()[2])+',')
			if arg.gyroscope or arg.all:
				line_buffer+=(str(tag.gyroscope.read()[0])+',')
				line_buffer+=(str(tag.gyroscope.read()[1])+',')
				line_buffer+=(str(tag.gyroscope.read()[2])+',')
			if (arg.light or arg.all) and tag.lightmeter is not None:
				line_buffer+=(str(tag.lightmeter.read())+',')

			file.write(line_buffer[:-1])
			file.write('\n')

			file.flush()
			tag.waitForNotifications(arg.t)
		except bluepy.btle.BTLEException as exception:
			print (str(datetime.now())+'			'+str(type(exception).__name__) + 'caught')
			print (str(datetime.now())+'			'+'RECONNECTING...')
			tag = sensortag.SensorTag(arg.host)
			enableSensors(arg, tag)

		#file.flush()
		#tag.waitForNotifications(arg.t)
	file.close()
	tag.disconnect()
	




if __name__ == '__main__':
	main()


    














